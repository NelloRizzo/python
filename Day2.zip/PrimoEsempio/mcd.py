
a = 12453
b = 1452

# il mcd tra a e b � uguale
# ad a se b == 0
while b != 0: # se b � diverso da 0
# oppure
#   si prende il resto della divisione tra a e b
    resto = a % b
#   si valorizza a con b 
    a = b
#   si valorizza b con il resto calcolato
    b = resto
#   e si prosegue fino a che b = 0
else:
    print(f"Il massimo comune divisore e' {a}")