print("Ciao, Mondo!")
nome = input("Inserisci il tuo nome: ")
print("Ciao, " + nome + "!")
print(f"Ciao, {nome}!")

numero = int(input("Inserisci un numero: "))
print(f"Hai inserito {numero}, il suo doppio e' {numero * 2}")

# dati due numeri stampare solo il pi� grande
num1 = int(input("Primo numero "))
num2 = int(input("Secondo numero "))
if num1 > num2:
    print(num1)
else:
    print(num2)

print(f"Primo: {num1}" if num1 > num2 else f"Secondo: {num2}")

# dati due numeri stampare la somma dei quadrati
print(f"Somma dei quadrati: {num1*num1+num2*num2}")
# dati due numeri stampare il pi� grande al quadrato meno il pi� piccolo
print("Il piu' grande al quadrato meno il piu' piccolo")
if (num1>num2):
    print(num1*num1-num2)
else:
    print(num2*num2-num1)

print(num1*num1-num2) if num1>num2 else print(num2*num2-num1)

