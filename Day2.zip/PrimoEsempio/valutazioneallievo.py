# supponiamo di voler chiedere ad un allievo la valutazione
# conseguita e esprimere un giudizio: 
# <= 5 bocciato, 6 = sufficiente, 7 = buono, 8 = discreto, 9 e 10 ottimo

# 1. chiedo il voto
voto = int(input("Quale voto hai ottenuto? "))

# 2. se il voto � <= 5
if voto <= 5:
# 2.1. stampo "bocciato"
    print("bocciato")
# 3. se il voto � 6
elif voto == 6:
# 3.1. stampo "sufficiente"
    print("sufficiente")
# ... e cos� via
elif voto == 7:
    print("buono")
elif voto == 8:
    print("discreto")
else:
    print("ottimo")
