i = 10
while i > 0:
    print(i)
    # i = i - 1
    i -= 1
while i < 11:
    print(i)
    i = i + 1
else:
    print(f"Adesso i e' >= 11, infatti vale {i}")

t = int(input("Quale tabellina vuoi stampare: "))
print(f"{t} e' pari'") if t % 2 == 0 else print(f"{t} e' dispari")
i = 1
while i <= 10:
    print(f"{t} per {i} fa {t * i}")
    # i = i + 1
    i += 1


