def email(testo, start=0):
    # 1. attraverso il testo carattere per carattere
    # 2. cerco una chiocciola
    # 2.1. per cercare la chiocciola devo scorrere il testo dall'inizio
    #      e posso memorizzare all'interno di una variabile la posizione della chiocciola
    posizione = -1  # qui c'� la posizione della chiocciola
    contatore = start - 1  # conto i caratteri
    for scanner in testo[start:]:
        contatore += 1  # viene incrementato di 1 ad ogni iterazione
        if scanner == "@" and posizione == -1:  # ho trovato la prima chiocciola
            posizione = contatore
            print(f"ho trovato la prima chiocciola in posizione {posizione}")

    # 3. se c'�, ho un "candidato" disponibile
    # 3.1. significa che dentro posizione ci sar� un'informazione != -1
    if posizione > -1:
        # 4. se ho un candidato disponibile
        # 4.1  devo prendere innanzitutto i caratteri che precedono la chiocciola fino ad un carattere
        #      non alfabetico (n� punto n� trattino n� underscore)
        #      questi caratteri rappresentano la casella
        # devo andare indietro fino a che o non ho pi� caratteri o trovo un carattere non alfabetico
        validi = "abcdefghijklmnopqrstuvwxyz._-"
        nome = ""
        scanner = posizione - 1
        while scanner >= 0 and testo[scanner] in validi:
            nome = testo[scanner] + nome
            scanner -= 1  # passo al carattere precedente
        print(nome)
        scanner = posizione + 1
        dominio = ""
        # 4.2  devo prendere i caratteri che seguono (come sopra)
        while scanner < len(testo) and testo[scanner] in validi:
            dominio += testo[scanner]
            scanner += 1
        print(dominio)
        # 4.3 affinch� l'email sia valida, ci deve essere il nome della casella
        #     e la parte a destra deve essere un possibile nome di dominio (ci deve essere almeno un punto non terminale)
        if len(nome) > 0 and "." in dominio and dominio[len(dominio) - 1] != ".":
            print(f"l'email {nome}@{dominio} e' valida")
            return {'casella': nome, 'dominio': dominio, 'valida': True, 'posizione': posizione}
        else:
            print(f"l'email {nome}@{dominio} non e' valida")
            return {'casella': nome, 'dominio': dominio, 'valida': False, 'posizione': posizione}


# dato un testo controllare se al suo interno � contenuto in indirizzo email
testo = "il mio indirizzo email e' nellorizzo@live.it, mentre l'indirizzo nello@nonesiste, non rappresenta un indirizzo email"
print(testo)
r1 = email(testo)
r2 = email(testo, 40)

if r1['valida']:
    print(f"Email valida: {r1['casella']}@{r1['dominio']}")
if r2['valida']:
    print(f"Email valida: {r2['casella']}@{r2['dominio']}")
