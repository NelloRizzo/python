# dato un numero intero in input, produrre la sua rappresentazione
# come stringa
# esempio: input -> 123 output: centoventitre
#


def translate(number):
    return (
        #se il numero � zero restituisci "zero"
        "zero"
        if number == 0
        # altrimenti se il numero � negativo restituisci 
        # innanzitutto "meno" e poi traduci il numero con il segno invertito
        else f"meno {translate_number(-number)}"
        if number < 0
        # altrimenti traduci il numero cos� com'�
        else translate_number(number)
    )


def translate_number(number):
    if number < 20:
        return translate_to_20(number)
    if number < 100:
        return translate_to_100(number)
    if number < 1000:
        return translate_to_1000(number)
    if number < 1000000:
        return translate_to_1000000(number)
    return "overflow"


def translate_to_20(number):
    if number == 0:
        return ""
    n = [
        "uno",
        "due",
        "tre",
        "quattro",
        "cinque",
        "sei",
        "sette",
        "otto",
        "nove",
        "dieci",
        "undici",
        "dodici",
        "tredici",
        "quattordici",
        "quindici",
        "sedici",
        "diciassette",
        "diciotto",
        "diciannove",
    ]
    return n[number - 1]


def translate_to_100(number):
    if number < 20:
        return translate_to_20(number)
    n = [
        "venti",
        "trenta",
        "quaranta",
        "cinquanta",
        "sessanta",
        "settanta",
        "ottanta",
        "novanta",
    ]
    return f"{n[int(number/10)-2]}{translate_to_20(number%10)}"


def translate_to_1000(number):
    if number < 100:
        return translate_to_100(number)
    u = int(number / 100)
    c = "cento" if u == 1 else f"{translate_to_100(u)}cento"
    return f"{c}{translate_to_100(number%100)}"


def translate_to_1000000(number):
    if number < 1000:
        return translate_to_1000(number)
    u = int(number / 1000)
    c = "mille" if u == 1 else f"{translate_to_1000(u)}mila"
    return f"{c}{translate_to_1000(number%1000)}"


print([translate(x) for x in range(11100, 11300)])