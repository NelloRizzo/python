
lista = [342, 3456, 4385675, 9578, 324, 43758, 5689, "Paperino", 1.342]
print(lista[2])
print(lista[2:5])
print(lista[:5])
print(lista[5:])
print(lista[-5:])
print(lista[-5:-2])

a = []
a.append(1)
a = a + [2, 3, 4]
a += [5, 6]
del a[2]
a.insert(2, 30)
print(a)

print(a.pop())
print(a)

print(10 in a)
print(30 in a)

for item in a:
    print(item)

for x in range(100):
    print(x)
for x in range(50, 100):
    print(x)
for x in range(50, 100, 5):
    print(x)

a = [f"Numero: {x}" for x in range(100) if x % 3 == 0]
print(a)

(a, b) = (10, 20)
print(a)
print(b)
a = (10, 20)
print(a[0])
# a[0] = 20 #una tupla � immutabile
v1, v2 = 10, 20
(v2, v1) = (v1, v2)
print(f"v1 = {v1} v2 = {v2}")

d = {1: "uno", 2: "due", 3: "tre"}
print(d[1])

d = {'uno':1, 'due':2, 'tre':3}
print(d['due'])
