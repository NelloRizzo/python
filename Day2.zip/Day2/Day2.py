def saluta():
    nome = "Nello"
    print(f"Ciao, {nome}!")
    print(f"Ciao, {nome}!")


def saluta2():
    print(f"Ciao, {nome}")


def saluta3(nome):
    print(f"Ciao, {nome}")


def min(x, y):
    print(x) if x < y else print(y)


def min2(x, y, z):
    print(x) if x < y and x < z else print(y) if y < x and y < z else print(z)

def calc_min(x,y,z):
    min = x if x < y and x < z else y if y < x and y < z else z
    return min


# print("Hello, welcome!")
##
# print("Hello, welcome!")
# print("Hello, welcome!")
# print("Hello, welcome!")
# print("Hello, welcome!")
# print("Hello, welcome!")
##
# print("Ciao, benvenuto!")
# print("Ciao, benvenuto!")
# print("Ciao, benvenuto!")
nome = "Paperino"
saluta()
print(nome)  # stampa il nome definito a livello globale
saluta2()
nome = "Topolino"
saluta2()
saluta3("Archimede")
saluta3("Pico De' Paperis")
min(10, 3)
min(312, 4323)
min(y=342, x=435)
min2(1, z=2, y=3)

value = calc_min(23,2345,367)
print(f"Il valore piu' piccolo e': {value}")