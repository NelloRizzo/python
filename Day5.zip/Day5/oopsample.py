# supponiamo di voler gestire delle operazioni aritmetiche che abbiano come
# parametro delle date, quindi avere la possibilit� di aggiungere giorni, mesi, anni
# a delle informazioni che possano rappresentare delle date (sempre valide)

# cosa � una data?
# una data � un insieme di giorno, mese e anno valorizzati secondo schemi
# ben precisi (giorni dei mesi diversi, febbraio particolare, ecc...)

# Concetti
# Data
#   |
#   +-- giorno
#   +-- mese
#   +-- anno
#   |
#   + aggiunge giorni(totale giorni da aggiungere)


class Date:
    __day = 1
    __month = 1
    __year = 1900

    def __is_leap_year(self, year) -> bool:
        return year % 4 == 0 and year % 400 != 0

    def __check(self, year, month, day) -> bool:
        # i giorni dei mesi dell'anno
        # febbraio ha 29 giorni se l'anno � bisestile
        month_days = [
            31,
            29 if self.__is_leap_year(year) else 28,
            31,
            30,
            31,
            30,
            31,
            31,
            30,
            31,
            30,
            31,
        ]
        return day > 0 and day <= month_days[month - 1]

    def __init__(self, year, month, day):
        if self.__check(year, month, day):
            self.__day = day
            self.__month = month
            self.__year = year
        else:
            raise Exception("Data non valida")

    def __str__(self) -> str:
        return f"{self.__day}/{self.__month}/{self.__year}"

    def add_days(self, days):
        # prendo i valori attuali
        d = self.__day
        m = self.__month
        y = self.__year
        # conto sui giorni da aggiungere
        while days > 0:
            # calcolo quali sono i giorni dei mesi relativi a d/m/y
            month_days = [
                31,
                29 if self.__is_leap_year(self.__year) else 28,
                31,
                30,
                31,
                30,
                31,
                31,
                30,
                31,
                30,
                31,
            ]
            # se i giorni sono minori dei giorni del mese
            if d < month_days[m - 1]:
                # aumento di un giorno
                d += 1
            else:  # altrimenti
                # passo al primo giorno del mese successivo
                d = 1  # d = 1 perch� sono al primo del mese
                if m < 12:  # se il mese � minore di dicembre
                    m += 1  # passo al mese successivo
                else:  # altrimenti
                    m = 1
                    year += 1  # passo all'anno successivo
            # decremento il numero totale di giorni da aggiungere
            days -= 1
        return Date(y, m, d)

    def __add__(self, d):
        return self.add_days(d)

d = Date(2023, 6, 26)
print(d)
#try:
#    d = Date(2023, 6, 31)
#    print(d)
#except:
#    print("Hai scritto una data non valida")
print(d.add_days(30))
print(d.add_days(40))

print (d + 40)
