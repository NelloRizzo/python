# supponiamo di voler gestire l'et� di una persona


class Person:
    __name = ""
    __surname = ""
    __age = 0

    def __init__(self, name, surname, age):
        self.__name = name
        self.__surname = surname
        self.__age = age

    def __lt__(self, other):
        if self.__age < other.__age:
            return True
        else:
            return False
    # def describe(self):
    def __str__(self):
        return f"{self.__name} {self.__surname} ({self.__age})"

    def __call__(self):
        print("Stai chiamando call()")


p = Person("Paperino", "Paolino", 51)
pp = Person("Paperon", "De' Paperoni", 80)

p()


def use_people(people):
    for x in people:
        # print(x.describe())
        print(x)


use_people(
    [p, pp, Person("Pico", "De' Paperis", 91), Person("Gastone", "De' Paperis", 50)]
)

if p < pp:
    print(f"Il piu' piccolo e' {p}")
else:
    print(f"Il piu' piccolo e' {pp}")