# Supponiamo di voler gestire le [persone] che arrivano in un ufficio postale
# che siano in grado di <presentarsi> alla postazione
# e che possano essere servite una ad una...

# Cosa si intende per "persona"?
# [Una persona] � caratterizzata da [un nome], [un cognome], [un codice identificativo
# univoco] (codice fiscale, carta di identit�) che consenta all'ufficio di poter individuare
# correttamente un cliente e poterlo correttamente distinguere da altri utenti
# dello stesso tipo.
# Cosa intendo per nome?
# [un nome] � [una sequenza di caratteri]
# Cosa intendo per cognome?
# un cognome � una sequenza di caratteri
# Cosa intendo per codice univoco?
# un codice univoco � una sequenza di caratteri
# Vincoli
# Ha senso una persona senza nome? NO -> nome � obbligatorio
# Ha senso una persona senza cognome? NO -> cognome � obbligatorio
# Ha senso una persona senza codice? SI -> il codice univoco non � obbligatorio
# +------------- Persona -----------------+
# | nome                stringa   OBB.    |
# | cognome             stringa   OBB.    |
# | codice univoco      stringa           |
# +---------------------------------------+
# | presentati al dipendente...           |
# +---------------------------------------+
#

class Persona:
    __nome = "Pinco"
    __cognome = "Pallino"
    __codiceunivoco = ""

    # costruttore
    def __init__(self, nome, cognome, codice=None) -> None:
        self.__nome = nome
        self.__cognome = cognome
        if codice is None:
            self.__codiceunivoco = f"{nome[-3:]}{cognome[-3:]}"
        else:
            self.__codiceunivoco = codice

    def presentati(self):
        print(
            f"Buongiorno, sono {self.__cognome} {self.__nome}, il mio codice e' '{self.__codiceunivoco}'"
        )


a = Persona("Archimede", "Pitagorico", "31415926")  # 'a' � ISTANZA di classe Persona
# a.__nome = "Archimede"
# a.__cognome = "Pitagorico"

p = Persona("Paperon", "De' Paperoni")
# p.__nome = ""
# p.__cognome = "De' Paperoni"

a.presentati()
p.presentati()  # come se avessi scritto: presentati(p)

l = [a, p]
for x in l:
    x.presentati()

def servizio(fila):
    for x in fila:
        print("Avanti il prossimo...")
        x.presentati()

servizio(l)

