# supponiamo di voler modellare un calcolatore che sia in grado di
# effettuare le 4 operazioni dell'aritmetica su numeri qualsiasi
# Analisi
# [Un calcolatore] � costituito da [un accumulatore] sul quale � in grado
# di <addizionare> un numero, <sottrarre>, <dividere> e <moltiplicare>
# in qualsiasi momento il valore dell'accumulatore rappresenta
# il risultato parziale mantenuto dal calcolatore
# Concetti:
# Calcolatore
#   |
#   +--- accumulatore
# Azioni
# addiziona(numero) -> addiziona il numero all'accumulatore
# sottrai(numero) -> sottrae il numero dall'accumulatore
# dividi(numero) -> divide l'accumulatore per il numero
# moltiplica(numero) -> addiziona il numero per l'accumulatore
class Calculator:
    __accumulator = 0.0

    def sub(self, number):
        self.__accumulator -= number

    def add(self, number):
        self.__accumulator += number

    def mul(self, number):
        self.__accumulator *= number

    def div(self, number):
        self.__accumulator /= number

    def result(self):
        return self.__accumulator


def my_calculator_service(calc):
    calc.sub(10)
    calc.add(20)
    calc.mul(30)
    calc.div(40)
    print(calc.result())

c1 = Calculator()
my_calculator_service(c1)

c2 = Calculator()
c2.add(100)
my_calculator_service(c2)